<?php

class AttackTypes
{
	const QUICK  = "Quick";
	const NORMAL = "Normal";
	const HEAVY  = "Heavy";
	const COUNT  = 3;
}