<?php

//I chose this way of handling potions because they're not going to be stackable, if you buy one it's used emediately.
class HealthPotion
{
	const HEAL_AMOUNT 		  = 5;
	const HEALTH_POTION_PRICE = 5;
}